const CACHE_NAME = 'heatlogik-calculator-v1';
const urlsToCache = [
    './heatlogik-calculator.html',
    './manifest.json',
    'https://cdn.tailwindcss.com',
    'https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap',
    // Add any other static assets (e.g., custom images if you replace placehold.co)
    'https://placehold.co/192x192/434343/ffffff?text=HL', // Placeholder icon
    'https://placehold.co/512x512/434343/ffffff?text=HL', // Placeholder icon
    'https://placehold.co/180x180/434343/ffffff?text=HL' // Apple touch icon
];

// Install event: Caches all essential assets
self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then((cache) => {
                console.log('Opened cache');
                return cache.addAll(urlsToCache);
            })
    );
});

// Fetch event: Intercepts network requests
self.addEventListener('fetch', (event) => {
    event.respondWith(
        caches.match(event.request)
            .then((response) => {
                // Cache hit - return response
                if (response) {
                    return response;
                }
                // No cache hit - fetch from network
                return fetch(event.request).catch(() => {
                    // This catch block handles network failures
                    // You could serve an offline page here if you had one
                    console.log('Network request failed and no cache found for:', event.request.url);
                    return new Response('<h1>Offline</h1><p>You are offline and this page is not cached.</p>', {
                        headers: { 'Content-Type': 'text/html' }
                    });
                });
            })
    );
});

// Activate event: Cleans up old caches
self.addEventListener('activate', (event) => {
    const cacheWhitelist = [CACHE_NAME];
    event.waitUntil(
        caches.keys().then((cacheNames) => {
            return Promise.all(
                cacheNames.map((cacheName) => {
                    if (cacheWhitelist.indexOf(cacheName) === -1) {
                        return caches.delete(cacheName); // Delete old caches
                    }
                })
            );
        })
    );
});

